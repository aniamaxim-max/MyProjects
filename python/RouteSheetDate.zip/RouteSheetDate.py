import os
import smtplib
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pandas as pd
import pyodbc

# ==================== НАСТРОЙКИ ====================
# 1. Параметры подключения к SQL Server
DB_CONFIG = {
    "server": "vent\\sqlexpress",
    "database": "Ania",
    "user": "Ania",
    "password": "12345",
}

# 2. Параметры отправки почты (на примере Gmail/Yandex)
MAIL_CONFIG = {
    "smtp_server": "smtp.gmail.com",  # Укажите ваш SMTP-сервер
    "smtp_port": 587,  # TLS порт (обычно 587 или 465)
    "sender_email": "aniamaxim@gmail.com",
    "sender_password": "opmx pnab wgnu xbrk",  # Пароль приложения (не обычный пароль!)
    "receiver_email": "aniamaxim@gmail.com",
}

# 3. Имя файла для выгрузки
OUTPUT_FILE = "routesheet_report.xlsx"
# ===================================================


def export_and_send():
    # Шаг 1: Подключение к БД и выполнение запроса
    conn_str = (
        f"DRIVER={{ODBC Driver 18 for SQL Server}};"
        f"SERVER=tcp:{DB_CONFIG['server']};"  # <--- Добавили приставку tcp:
        f"DATABASE={DB_CONFIG['database']};"
        f"UID={DB_CONFIG['user']};"
        f"PWD={DB_CONFIG['password']};"
        f"Encrypt=yes;"
        f"TrustServerCertificate=yes;"
    )

    query = "SELECT TOP 10 * FROM CarNumbers"

    print("Подключение к базе данных...")
    try:
        with pyodbc.connect(conn_str) as conn:
            # pandas автоматически выполняет запрос и создает DataFrame
            df = pd.read_sql(query, conn)
            print(f"Запрос успешно выполнен. Получено строк: {len(df)}")

            # Шаг 2: Выгрузка в Excel (для CSV замените на df.to_csv(..., index=False))
            df.to_excel(OUTPUT_FILE, index=False, engine="openpyxl")
            print(f"Данные сохранены в файл: {OUTPUT_FILE}")
    except Exception as e:
        print(f"Ошибка при работе с БД: {e}")
        return

    # Шаг 3: Формирование и отправка письма
    print("Подготовка к отправке почты...")
    msg = MIMEMultipart()
    msg["From"] = MAIL_CONFIG["sender_email"]
    msg["To"] = MAIL_CONFIG["receiver_email"]
    msg["Subject"] = "Автоматическая выгрузка: Маршрутные листы"

    # Текст письма
    body = "Приветствую!\n\nВо вложении находится свежая выгрузка по запросу pbi.v_routesheet."
    msg.attach(MIMEText(body, "plain"))

    # Прикрепление файла
    try:
        with open(OUTPUT_FILE, "rb") as f:
            attachment = MIMEApplication(f.read(), _subtype="xlsx")
            attachment.add_header(
                "Content-Disposition", "attachment", filename=OUTPUT_FILE
            )
            msg.attach(attachment)

        # Подключение к SMTP серверу и отправка
        server = smtplib.SMTP(
            MAIL_CONFIG["smtp_server"], MAIL_CONFIG["smtp_port"]
        )
        server.starttls()  # Шифрование соединения
        server.login(MAIL_CONFIG["sender_email"], MAIL_CONFIG["sender_password"])
        server.send_message(msg)
        server.quit()
        print("Письмо успешно отправлено!")

    except Exception as e:
        print(f"Ошибка при отправке почты: {e}")

    finally:
        # Удаляем локальный файл после отправки (опционально)
        if os.path.exists(OUTPUT_FILE):
            os.remove(OUTPUT_FILE)
            print("Временный файл удален.")


if __name__ == "__main__":
    export_and_send()
